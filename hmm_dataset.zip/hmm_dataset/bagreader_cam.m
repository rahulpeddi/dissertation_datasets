
clear
clc
close all

tic

headings = [0 pi/4 pi/2 -pi/4 pi -3*pi/4 -pi/2 3*pi/4];

topic = {'/vicon/helmet/helmet'};
topic2 = {'/vicon/ridge/ridge'};
bags = dir('*.bag');

% figure

acc = 0.5;
    
for i = 1:length(bags)
    
bag = rosbag(bags(i).name);

bSel = select(bag,'Topic',topic);
msgStructs = readMessages(bSel,'DataFormat','struct');

vxP{i} = cellfun(@(m) (m.Transform.Translation.X),msgStructs)';
vyP{i} = cellfun(@(m) (m.Transform.Translation.Y),msgStructs)';
vzP{i} = cellfun(@(m) (m.Transform.Translation.Z),msgStructs)';

bSel2 = select(bag,'Topic',topic2);
msgStructs2 = readMessages(bSel2,'DataFormat','struct');

vxP2{i} = cellfun(@(m) (m.Transform.Translation.X),msgStructs2)';
vyP2{i} = cellfun(@(m) (m.Transform.Translation.Y),msgStructs2)';
vzP2{i} = cellfun(@(m) (m.Transform.Translation.Z),msgStructs2)';

lspace = 70;

vxRob{i} = round(vxP2{i}(1:lspace:end)./acc).*acc;
vyRob{i} = round(vyP2{i}(1:lspace:end)./acc).*acc;
vzRob{i} = round(vyP2{i}(1:lspace:end)./acc).*acc;

vxHum{i} = round(vxP{i}(1:lspace:end)./acc).*acc;
vyHum{i} = round(vyP{i}(1:lspace:end)./acc).*acc;
vzHum{i} = round(vyP{i}(1:lspace:end)./acc).*acc;

vxRob_nr{i} = vxP2{i}(1:lspace:end);
vyRob_nr{i} = vyP2{i}(1:lspace:end);
vzRob_nr{i} = vzP2{i}(1:lspace:end);
vxHum_nr{i} = vxP{i}(1:lspace:end);
vyHum_nr{i} = vyP{i}(1:lspace:end);
vzHum_nr{i} = vyP{i}(1:lspace:end);


% hold on

% figure(1)
% title('Discretized Training Trajectories')
% hold on
% plot(vxHum{i},vyHum{i},'-','LineWidth',2)
% xlim([-2 2])
% ylim([-2.5 3])
% grid on
% 
% 
% figure(2)
% title('Training Trajectories')
% hold on
% plot(vxHum_nr{i},vyHum_nr{i},'-','LineWidth',2)
% xlim([-2 2])
% ylim([-2.5 3])
% grid on

shorter = min(length(vxRob{i}),length(vxHum{i}));

distx{i} = vxHum{i}(1:shorter)-vxRob{i}(1:shorter);
disty{i} = vyHum{i}(1:shorter)-vyRob{i}(1:shorter);


for an = 2:shorter
    ang{i}(an) = roundtowardvec(atan2(vyHum{i}(an)-vyHum{i}(an-1),vxHum{i}(an)-vxHum{i}(an-1)),headings); 
end

ang{i}(1) = 0;

for ii = 1:shorter
    
    state{i}(ii,:) = [distx{i}(ii) disty{i}(ii) ang{i}(ii)]; 
 
end
end

for kk = 1:length(state)
    state{kk}(end+1,:) = [0 -100 0];
end
 
allstates_old = cell2mat(state(:));
allstates = allstates_old;

statenote = unique(allstates(:,:), 'rows','stable');

for i = 1:length(allstates)
    for j = 1:length(statenote)
        if numel(find(allstates(i,:)==statenote(j,:)))==3
            statevec(i,:) = j;
        end
    end
    i;
end

emi = ones(length(statevec),1);

emis = repmat([0.5 0.5],[length(statenote) 1]);

pstrans = ones(length(statenote))*(1/length(statenote));
[trans,~] = hmmestimate(emi,statevec,'Pseudotransitions',pstrans);

for trc = 1:length(trans)
    tot(trc,1) = numel(find(trans(trc,:)));
end

EXP_cam.trans  = trans;
EXP_cam.emis = emis;
EXP_cam.statenote = statenote;
EXP_cam.statevec = statevec;

save('EXP_cam.mat','EXP_cam')




% % %%%%%% NO HEADING TEST
% % 
% % 
% % for ii = 1:shorter
% %     
% %     state{i}(ii,:) = [distx{i}(ii) disty{i}(ii)]; 
% %  
% % end
% % end
% % 
% % for kk = 1:length(state)
% %     state{kk}(end+1,:) = [0 -100];
% % end
% %  
% % allstates_old = cell2mat(state(:));
% % allstates = allstates_old;
% % 
% % statenote = unique(allstates(:,:), 'rows','stable');
% % 
% % for i = 1:length(allstates)
% %     for j = 1:length(statenote)
% %         if numel(find(allstates(i,:)==statenote(j,:)))==2
% %             statevec(i,:) = j;
% %         end
% %     end
% %     i;
% % end
% % 
% % emi = ones(length(statevec),1);
% % 
% % emis = repmat([0.5 0.5],[length(statenote) 1]);
% % 
% % pstrans = ones(length(statenote))*(1/length(statenote));
% % [trans,~] = hmmestimate(emi,statevec,'Pseudotransitions',pstrans);
% % 
% % for trc = 1:length(trans)
% %     tot(trc,1) = numel(find(trans(trc,:)));
% % end
% % 
% % EXP_nohead.trans  = trans;
% % EXP_nohead.emis = emis;
% % EXP_nohead.statenote = statenote;
% % EXP_nohead.statevec = statevec;
% % 
% % save('EXP_nohead.mat','EXP_nohead')
