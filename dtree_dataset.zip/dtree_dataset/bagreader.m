
clear
clc
close all

tic
lanes = [-1 0 1];
headings = [0 pi/4 pi/2 -pi/4 pi -3*pi/4 -pi/2 3*pi/4];

topic = {'/vicon/helmet/helmet'};
topic2 = {'/vicon/ridge/ridge'};
bags = dir('*.bag');

f = figure(1);
f.Color = 'white';
    
for i = 1:length(bags)
      
bag = rosbag(bags(i).name);

bSel = select(bag,'Topic',topic);
msgStructs = readMessages(bSel,'DataFormat','struct');

vxP{i} = cellfun(@(m) (m.Transform.Translation.X),msgStructs)';
vyP{i} = cellfun(@(m) (m.Transform.Translation.Y),msgStructs)';
vzP{i} = cellfun(@(m) (m.Transform.Translation.Z),msgStructs)';

bSel2 = select(bag,'Topic',topic2);
msgStructs2 = readMessages(bSel2,'DataFormat','struct');

vxP2{i} = cellfun(@(m) (m.Transform.Translation.X),msgStructs2)';
vyP2{i} = cellfun(@(m) (m.Transform.Translation.Y),msgStructs2)';
vzP2{i} = cellfun(@(m) (m.Transform.Translation.Z),msgStructs2)';

lspace = 1;

vxRob_nr{i} = (vxP2{i}(1:lspace:end));
vyRob_nr{i} = vyP2{i}(1:lspace:end);
vzRob_nr{i} = vzP2{i}(1:lspace:end);
vxHum_nr{i} = vxP{i}(500:lspace:end-300);
vyHum_nr{i} = vyP{i}(500:lspace:end-300);
vzHum_nr{i} = vyP{i}(500:lspace:end-300);


title('Experiment Trajectories')
hold on
plot(vxHum_nr{i}(1),vyHum_nr{i}(1),'*','MarkerSize',5)
plot(vxHum_nr{i},vyHum_nr{i},'-','LineWidth',2)
plot(vxRob_nr{i},vyRob_nr{i},'k--','LineWidth',2)
xlim([-2 2])
ylim([-2.5 3])
xlabel('X(m)')
ylabel('Y(m)')
set(gca,'fontname','times')
set(gca,'fontsize',16)
grid on

drawnow;

cla

end

% profile veiwer

% % % create the video writer with 30 fps
%   writerObj = VideoWriter('training','MPEG-4');
%   writerObj.FrameRate = 10;
% % set the seconds per image
% % open the video writer
% open(writerObj);
% % write the frames to the video
% 
% for i= 2:length(F)
%     % convert the image to a frame
%     frame = F(i);    
%     writeVideo(writerObj, frame);
% end
% % close the writer object
% close(writerObj);
